(() => {
  const form = document.getElementById('checkout-form');
  if (!form) return;
  const cart = new Map();
  const money = n => 'LKR ' + Number(n).toLocaleString('en-LK', {minimumFractionDigits:2, maximumFractionDigits:2});
  const cartItems = document.getElementById('cart-items');
  const subtotalEl = document.getElementById('subtotal');
  const totalEl = document.getElementById('total');
  const changeEl = document.getElementById('change');
  const paidEl = document.getElementById('amount-paid');
  const submit = document.getElementById('complete-sale');

  function render() {
    let total = 0, count = 0;
    cartItems.innerHTML = '';
    if (!cart.size) cartItems.innerHTML = '<p class="empty">Select products to start an order.</p>';
    cart.forEach(item => {
      count += item.quantity; total += item.price * item.quantity;
      const row = document.createElement('div'); row.className = 'cart-row';
      const info = document.createElement('div');
      const name = document.createElement('strong'); name.textContent = item.name;
      const price = document.createElement('small'); price.textContent = money(item.price) + ' each';
      info.append(name, price);
      const controls = document.createElement('div'); controls.className = 'qty-controls';
      const minus = document.createElement('button'); minus.type='button'; minus.textContent='−'; minus.setAttribute('aria-label','Decrease quantity');
      const qty = document.createElement('span'); qty.textContent=item.quantity;
      const plus = document.createElement('button'); plus.type='button'; plus.textContent='+';
      const remove = document.createElement('button'); remove.type='button'; remove.className='remove-item'; remove.textContent='×'; remove.setAttribute('aria-label','Remove item');
      minus.onclick=()=>{item.quantity--; if(item.quantity<=0) cart.delete(item.id); render();};
      plus.onclick=()=>{if(item.quantity<99)item.quantity++;render();};
      remove.onclick=()=>{cart.delete(item.id);render();};
      controls.append(minus,qty,plus,remove); row.append(info,controls); cartItems.append(row);
    });
    document.getElementById('item-count').textContent = count + (count===1?' item':' items');
    subtotalEl.textContent=money(total); totalEl.textContent=money(total);
    const paid=Number(paidEl.value||0); changeEl.textContent=money(Math.max(0,paid-total));
    submit.disabled = !cart.size || paid < total;
    submit.textContent = !cart.size ? 'Add items to continue' : paid < total ? 'Enter full payment amount' : 'Complete sale →';
  }
  document.querySelectorAll('.product-tile').forEach(tile => tile.addEventListener('click',()=>{
    const id=Number(tile.dataset.id);
    if(!cart.has(id)) cart.set(id,{id,name:tile.dataset.name,price:Number(tile.dataset.price),quantity:0});
    const item=cart.get(id); if(item.quantity<99)item.quantity++; render();
  }));
  paidEl.addEventListener('input',render);
  const search=document.getElementById('product-search');
  search.addEventListener('input',()=>{
    const term=search.value.toLowerCase();
    document.querySelectorAll('.product-tile').forEach(tile=>{
      tile.hidden=!(tile.dataset.name.toLowerCase().includes(term)||tile.dataset.category.toLowerCase().includes(term));
    });
  });
  form.addEventListener('submit',e=>{
    if(!cart.size){e.preventDefault();return;}
    const total=[...cart.values()].reduce((sum,item)=>sum+item.price*item.quantity,0);
    if(Number(paidEl.value)<total){e.preventDefault();alert('Amount received must cover the total.');return;}
    const hidden=document.createElement('input'); hidden.type='hidden'; hidden.name='cart_json';
    hidden.value=JSON.stringify([...cart.values()].map(({id,quantity})=>({id,quantity})));
    form.append(hidden);
    submit.disabled=true; submit.textContent='Saving sale…';
  });
  render();
})();
