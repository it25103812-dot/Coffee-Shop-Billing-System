<?php
require_once __DIR__ . '/auth.php';
$pageTitle = $pageTitle ?? 'Dashboard';
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= h($pageTitle) ?> | Brew & Bean POS</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="app-shell">
  <aside class="sidebar">
    <a class="brand" href="dashboard.php"><span class="brand-icon">☕</span><span>Brew & Bean<small>COFFEE POS</small></span></a>
    <nav>
      <a href="dashboard.php">▦ <span>Dashboard</span></a>
      <a href="billing.php">▣ <span>New Bill</span></a>
      <a href="products.php">▤ <span>Products</span></a>
      <a href="sales.php">▥ <span>Sales History</span></a>
    </nav>
    <div class="sidebar-bottom"><span>Signed in as</span><strong><?= h(current_user()) ?></strong><a href="logout.php">↪ Sign out</a></div>
  </aside>
  <main class="main-content">
    <header class="topbar"><div><span class="eyebrow">COFFEE SHOP MANAGEMENT</span><h1><?= h($pageTitle) ?></h1></div><div class="user-pill">● <?= h(current_user()) ?></div></header>
